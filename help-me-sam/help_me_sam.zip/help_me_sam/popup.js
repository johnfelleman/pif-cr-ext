// Copyright (c) 2013

$("#h2").text("Welcome to the SAM helper");
// $("#pageheader").text( $(".page_heading").val);
